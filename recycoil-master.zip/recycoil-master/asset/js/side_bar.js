var bt_search1 = document.querySelector(".search-button span");
var bt_search2 = document.querySelector(".search-button button");
bt_search1.addEventListener('click' , function (){
    var icon = bt_search1.querySelector("#icon");
    var bool = false;
    if(icon.getAttribute("class") == "fa fa-search" || icon.getAttribute("class")==""){
        icon.setAttribute("class","fa fa-times");
        bt_search2.style.display = "block";
        var div = document.querySelector(".search-form").querySelectorAll(".search-div");
        for (let i=0 ; i<div.length ; i++){
            div[i].style.width = "100%";
        }
        bool = true;
    }
    if(icon.getAttribute("class") == "fa fa-times" && bool == false){
        icon.setAttribute("class","fa fa-search");
        bt_search2.style.display = "none";
        var div = document.querySelector(".search-form").querySelectorAll(".search-div");
        for (let i=0 ; i<div.length ; i++){
            div[i].style.width = "0%";
        }
    }
});