function show_sideBar(div){
    var nav_list = div.querySelector(".nav-list");
    var arrow = div.querySelector("#arrow");
    var bool = false;
    if(nav_list.style.display == "" || nav_list.style.display == "none"){
        arrow.style.transform = "rotate(-90deg)";
        nav_list.style.display = "block";
        bool = true;
    }
    if(bool==false && nav_list.style.display == "block"){
        arrow.style.transform = "rotate(0deg)";
        nav_list.style.display = "none";
    }
}