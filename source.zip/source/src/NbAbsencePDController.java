package absence;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class NbAbsencePDController extends HttpServlet{
    public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
    {
       	
	}
    public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
        try
		{  
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); // Format de date du champ date
            Date earlier_date=new Date(dateFormat.parse(request.getParameter("earlier_date")).getTime());
            Date later_date=new Date(dateFormat.parse(request.getParameter("lateer_date")).getTime());

            out.print(NbAbsenceParMois.getNbAbsParMoisJSON(earlier_date,later_date));

            out.close();

		}
	    catch(Exception e){
	 		e.printStackTrace();
	    }	
	}
}