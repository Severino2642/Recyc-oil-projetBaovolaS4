package repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import models.Personnel;
import models.Poste;

public class PersonnelRepository {
    private Connection connection;
    private PosteRepository posteRepository;

    public PersonnelRepository(Connection connection) {
        this.connection =  connection;
        this.posteRepository = new PosteRepository(connection);
    }

    public void create(Poste poste, String nom, String prenom, String email, LocalDate dateNaissance, double salaire, String adresse, String telephone, LocalDate dateEmbauche) {
        String sql = "INSERT INTO Personnel (id_Poste, Nom, Prenom, Email, Date_Naissance, Salaire, Addresse, numero_Telephone, Date_Embauche) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, poste.getId_Poste());
            statement.setString(2, nom);
            statement.setString(3, prenom);
            statement.setString(4, email);
            statement.setDate(5, java.sql.Date.valueOf(dateNaissance));
            statement.setDouble(6, salaire);
            statement.setString(7, adresse);
            statement.setString(8, telephone);
            statement.setDate(9, java.sql.Date.valueOf(dateEmbauche));
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Personnel> read() {
        List<Personnel> personnels = new ArrayList<>();
        String sql = "SELECT * FROM Personnel";
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet resultSet = statement.executeQuery()) {
            System.out.println("Personnel :");
            while (resultSet.next()) {
                int id_Personnel = resultSet.getInt("id_Personnel");
                int id_Poste = resultSet.getInt("id_Poste");
                Poste poste = posteRepository.read(id_Poste);
                String nom = resultSet.getString("Nom");
                String prenom = resultSet.getString("Prenom");
                String email = resultSet.getString("Email");
                LocalDate dateNaissance = resultSet.getDate("Date_Naissance").toLocalDate();
                double salaire = resultSet.getDouble("Salaire");
                String adresse = resultSet.getString("Addresse");
                String telephone = resultSet.getString("numero_Telephone");
                LocalDate dateEmbauche = resultSet.getDate("Date_Embauche").toLocalDate();
                Personnel p = new Personnel(id_Personnel, poste, nom, prenom, email, dateNaissance, salaire, adresse, telephone, dateEmbauche);
                personnels.add(p);
                System.out.println("ID : " + id_Personnel + ", Nom : " + nom + ", Prénom : " + prenom + ", Poste : " + poste.getPoste());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return personnels;
    }

    public Personnel read(int id_Personnel) {
        String sql = "SELECT * FROM Personnel WHERE id_Personnel = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id_Personnel);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int id_Poste = resultSet.getInt("id_Poste");
                    Poste poste = posteRepository.read(id_Poste);
                    String nom = resultSet.getString("Nom");
                    String prenom = resultSet.getString("Prenom");
                    String email = resultSet.getString("Email");
                    LocalDate dateNaissance = resultSet.getDate("Date_Naissance").toLocalDate();
                    double salaire = resultSet.getDouble("Salaire");
                    String adresse = resultSet.getString("Addresse");
                    String telephone = resultSet.getString("numero_Telephone");
                    LocalDate dateEmbauche = resultSet.getDate("Date_Embauche").toLocalDate();
                    Personnel p = new Personnel(id_Personnel, poste, nom, prenom, email, dateNaissance, salaire, adresse, telephone, dateEmbauche);
                    System.out.println("Personnel récupéré : ID " + id_Personnel + ", Nom : " + nom + ", Prénom : " + prenom + ", Poste : " + poste.getPoste());
                    return p;
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void update(int id_Personnel, Poste poste, String nom, String prenom, String email, LocalDate dateNaissance, double salaire, String adresse, String telephone, LocalDate dateEmbauche) {
        String sql = "UPDATE Personnel SET id_Poste = ?, Nom = ?, Prenom = ?, Email = ?, Date_Naissance = ?, Salaire = ?, Addresse = ?, numero_Telephone = ?, Date_Embauche = ? WHERE id_Personnel = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, poste.getId_Poste());
            statement.setString(2, nom);
            statement.setString(3, prenom);
            statement.setString(4, email);
            statement.setDate(5, java.sql.Date.valueOf(dateNaissance));
            statement.setDouble(6, salaire);
            statement.setString(7, adresse);
            statement.setString(8, telephone);
            statement.setDate(9, java.sql.Date.valueOf(dateEmbauche));
            statement.setInt(10, id_Personnel);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(int id_Personnel) {
        String sql = "DELETE FROM Personnel WHERE id_Personnel = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id_Personnel);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}