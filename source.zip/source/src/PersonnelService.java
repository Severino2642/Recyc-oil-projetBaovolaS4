package services;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.List;
import repositories.*;
import  models.*;
import baseUtil.*;
public class PersonnelService {
    private Connection databaseConnection;
    private PersonnelRepository personnelRepository;
    private PosteRepository posteRepository;

    public PersonnelService() {
        databaseConnection = ConnexionPgsql.dbConnect();
        this.personnelRepository = new PersonnelRepository(databaseConnection);
        this.posteRepository = new PosteRepository(databaseConnection);
    }

    public void createPersonnel(Poste poste, String nom, String prenom, String email, LocalDate dateNaissance, double salaire, String adresse, String telephone, LocalDate dateEmbauche) {
        personnelRepository.create(poste, nom, prenom, email, dateNaissance, salaire, adresse, telephone, dateEmbauche);
    }

    public List<Personnel> getAllPersonnel() {
        return personnelRepository.read();
    }

    public Personnel getPersonnelById(int id_Personnel) {
        return personnelRepository.read(id_Personnel);
    }

    public void updatePersonnel(int id_Personnel, Poste poste, String nom, String prenom, String email, LocalDate dateNaissance, double salaire, String adresse, String telephone, LocalDate dateEmbauche) {
        personnelRepository.update(id_Personnel, poste, nom, prenom, email, dateNaissance, salaire, adresse, telephone, dateEmbauche);
    }

    public void deletePersonnel(int id_Personnel) {
        personnelRepository.delete(id_Personnel);
    }

    public List<Poste> getAllPostes() {
        return posteRepository.read();
    }

    public Poste getPosteById(int id_Poste) {
        return posteRepository.read(id_Poste);
    }
}