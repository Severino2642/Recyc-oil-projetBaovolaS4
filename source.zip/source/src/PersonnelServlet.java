package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.Personnel;
import models.Poste;
import services.PersonnelService;

@WebServlet(name = "PersonnelServlet", urlPatterns = {"/personnel", "/personnel/add", "/personnel/update", "/personnel/delete"})
public class PersonnelServlet extends HttpServlet {
    private final PersonnelService personnelService;

    public PersonnelServlet() {
        this.personnelService = new PersonnelService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        switch (path) {
            case "/personnel":
                doListPersonnel(request, response);
                break;
            case "/personnel/update":
                doUpdatePersonnelForm(request, response);
                break;
            case "/personnel/delete":
                doDeletePersonnel(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        switch (path) {
            case "/personnel/add":
                doAddPersonnel(request, response);
                break;
            case "/personnel/update/*":
                doUpdatePersonnel(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                break;
        }
    }

    private void doListPersonnel(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Personnel> personnels = personnelService.getAllPersonnel();
        List<Poste> postes = personnelService.getAllPostes();
        request.setAttribute("personnels", personnels);
        request.setAttribute("postes", postes);
        request.getRequestDispatcher("personnel.jsp").forward(request, response);
    }

    private void doAddPersonnel(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id_Poste = Integer.parseInt(request.getParameter("id_Poste"));
        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String email = request.getParameter("email");
        String dateNaissanceString = request.getParameter("dateNaissance");
        LocalDate dateNaissance = LocalDate.parse(dateNaissanceString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        double salaire = Double.parseDouble(request.getParameter("salaire"));
        String adresse = request.getParameter("adresse");
        String telephone = request.getParameter("telephone");
        String dateEmbaucheString = request.getParameter("dateEmbauche");
        LocalDate dateEmbauche = LocalDate.parse(dateEmbaucheString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        Poste poste = personnelService.getAllPostes().stream()
                .filter(p -> p.getId_Poste() == id_Poste)
                .findFirst()
                .orElse(null);
        personnelService.createPersonnel(poste, nom, prenom, email, dateNaissance, salaire, adresse, telephone, dateEmbauche);
        response.sendRedirect(request.getContextPath() + "/personnel");
    }

    private void doUpdatePersonnelForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idPersonnelParam = request.getParameter("id_Personnel");
        if (idPersonnelParam != null) {
            try {
                int id_Personnel = Integer.parseInt(idPersonnelParam);
                Personnel personnel = personnelService.getPersonnelById(id_Personnel);
                List<Poste> postes = personnelService.getAllPostes();
                request.setAttribute("personnel", personnel);
                request.setAttribute("postes", postes);
                request.getRequestDispatcher("personnel-form.jsp").forward(request, response);
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid personnel ID");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing personnel ID");
        }
    }

    private void doUpdatePersonnel(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idPersonnelParam = request.getParameter("id_Personnel");
        if (idPersonnelParam != null) {
            try {
                int id_Personnel = Integer.parseInt(idPersonnelParam);
                int id_Poste = Integer.parseInt(request.getParameter("id_Poste"));
                String nom = request.getParameter("nom");
                String prenom = request.getParameter("prenom");
                String email = request.getParameter("email");
                String dateNaissanceString = request.getParameter("dateNaissance");
                LocalDate dateNaissance = LocalDate.parse(dateNaissanceString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                double salaire = Double.parseDouble(request.getParameter("salaire"));
                String adresse = request.getParameter("adresse");
                String telephone = request.getParameter("telephone");
                String dateEmbaucheString = request.getParameter("dateEmbauche");
                LocalDate dateEmbauche = LocalDate.parse(dateEmbaucheString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                Poste poste = personnelService.getAllPostes().stream()
                        .filter(p -> p.getId_Poste() == id_Poste)
                        .findFirst()
                        .orElse(null);
                personnelService.updatePersonnel(id_Personnel, poste, nom, prenom, email, dateNaissance, salaire, adresse, telephone, dateEmbauche);
                response.sendRedirect(request.getContextPath() + "/personnel");
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid personnel ID");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing personnel ID");
        }
    }

    private void doDeletePersonnel(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idPersonnelParam = request.getParameter("id_Personnel");
        if (idPersonnelParam != null) {
            try {
                int id_Personnel = Integer.parseInt(idPersonnelParam);
                personnelService.deletePersonnel(id_Personnel);
                response.sendRedirect(request.getContextPath() + "/personnel");
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid personnel ID");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing personnel ID");
        }
    }
}