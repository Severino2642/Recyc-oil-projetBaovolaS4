package absence;

import utils.AssistantDB;
import utils.DateUtil;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.sql.*;


public class Main{
 public static void main(String[] args) {
    try {
      
    } catch (Exception e) {
      // TODO: handle exception
    }
 }



}