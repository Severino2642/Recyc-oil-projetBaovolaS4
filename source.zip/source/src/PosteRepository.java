package repositories;

import models.Poste;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PosteRepository {
    private Connection connection;

    public PosteRepository(Connection connection) {
        this.connection = connection;
    }

    public void create(String poste) {
        String sql = "INSERT INTO poste (poste) VALUES (?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, poste);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Poste> read() {
        List<Poste> postes = new ArrayList<>();
        String sql = "SELECT * FROM Poste";
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet resultSet = statement.executeQuery()) {
            System.out.println("Postes :");
            while (resultSet.next()) {
                int id_Poste = resultSet.getInt("id_Poste");
                String poste = resultSet.getString("Poste");
                Poste p = new Poste(id_Poste, poste);
                postes.add(p);
                System.out.println("ID : " + id_Poste + ", Poste : " + poste);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return postes;
    }

    public Poste read(int id_Poste) {
        String sql = "SELECT * FROM Poste WHERE id_Poste = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id_Poste);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String poste = resultSet.getString("Poste");
                    Poste p = new Poste(id_Poste, poste);
                    System.out.println("Poste récupéré : ID " + id_Poste + ", Poste : " + poste);
                    return p;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void update(int id_Poste, String poste) {
        String sql = "UPDATE poste SET poste = ? WHERE id_Poste = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, poste);
            statement.setInt(2, id_Poste);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void delete(int id_Poste) {
        String sql = "DELETE FROM poste WHERE id_Poste = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id_Poste);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}