package stock;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;
import java.util.Vector;
import need.*;
import vente.Vente;
import baseUtil.*;

public class Dashboard_servlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    private String buildBeneficeJsonResponse(List<Benefice> benefices) {
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < benefices.size(); i++) {
            Benefice benefice = benefices.get(i);
            json.append("{");
            json.append('"').append("annee").append('"').append(":"+benefice.getAnnee()).append(",");
            json.append('"').append("mois").append('"').append(":"+benefice.getMois()).append(",");
            json.append('"').append("benefice").append('"').append(":"+benefice.getBenefice());
            json.append("}");
            if (i < benefices.size() - 1) {
                json.append(",");
            }
        }
        json.append("]");
        return json.toString();
    }
    private String buildVenteJsonResponse(List ventes) {
        StringBuilder json = new StringBuilder("[");
        String[] keys = {"annee", "mois", "montant"};
        for (int i = 0; i < ventes.size(); i++) {
            List vente = (List)ventes.get(i);
            json.append("{");
            for(int j=0 ; j < vente.size() ; j++){
                json.append('"').append(keys[j%keys.length]).append('"').append(":"+vente.get(j));
                if (j < vente.size() - 1) {
                    json.append(",");
                }
            }
            json.append("}");
            if (i < ventes.size() - 1) {
                json.append(",");
            }
        }
        json.append("]");
        return json.toString();
    }
    private String buildDepenseJsonResponse(List depenses) {
        StringBuilder json = new StringBuilder("[");
        String[] keys = {"annee", "mois", "montant"};
        for (int i = 0; i < depenses.size(); i++) {
            List depense = (List)depenses.get(i);
            json.append("{");
            for(int j=0 ; j < depense.size() ; j++){
                json.append('"').append(keys[j%keys.length]).append('"').append(":"+depense.get(j));
                if (j < depense.size() - 1) {
                    json.append(",");
                }
            }
            json.append("}");
            if (i < depenses.size() - 1) {
                json.append(",");
            }
        }
        json.append("]");
        return json.toString();
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        try {
///asina valeur par defaut le ixy de ny mois sy date misy zao sy sy ny 3 mois aloanzao 
            LocalDate currentDate = LocalDate.now();
            int mois = currentDate.getMonthValue();
            int annee = currentDate.getYear();
            Vector dash = new Vector();
            List depense = Depense.get_entre_deux_mois(annee, mois-3, annee, mois);
            List vente = Vente.get_vente_deux_mois(annee, annee, mois-3, mois);
            List<Benefice> benefice = Benefice.getBenefices(annee, annee, mois-3, mois, ConnexionPgsql.dbConnect());
            List total_vente = Vente.get_vente_deux_mois(annee, annee, mois-3, mois);
            String depensesJson = this.buildDepenseJsonResponse(depense);
            String beneficeJson = this.buildBeneficeJsonResponse(benefice);
            String venteJson = this.buildVenteJsonResponse(vente);
            String vente_total_json = this.buildVenteJsonResponse(total_vente);
            StringBuilder builder = new StringBuilder();
            builder.append("{");
            builder.append('"').append("depenses").append('"').append(":").append(depensesJson).append(",");
            builder.append('"').append("benefices").append('"').append(":").append(beneficeJson).append(",");
            builder.append('"').append("vente").append('"').append(":").append(venteJson).append(",");
            builder.append('"').append("vente_total").append('"').append(":").append(vente_total_json);
            builder.append("}");
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            String jsonResponse = builder.toString();
            // request.setAttribute("jsonResponse", jsonResponse);
            // request.getRequestDispatcher("Dashboard.jsp").forward(request, response);
            out.print(jsonResponse);
            out.flush();
        } catch (Exception e) {
            out.println(e.getMessage());
        }
        
    }
    
}
